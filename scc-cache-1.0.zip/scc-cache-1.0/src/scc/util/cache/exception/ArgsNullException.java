package scc.util.cache.exception;

public class ArgsNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4328440503523770925L;

	public ArgsNullException() {
		// TODO Auto-generated constructor stub
	}

	public ArgsNullException(String message) {
		super(message);
	}

}
